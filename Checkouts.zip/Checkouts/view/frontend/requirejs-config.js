var config = {
    config: {
        mixins: {
            'Magento_Checkout/js/action/place-order': {
                'Navigate_Checkouts/js/order/place-order-mixin': true
            },
            'Magento_Checkout/js/action/set-payment-information': {
                'Navigate_Checkouts/js/order/set-payment-information-mixin': true
            },
            'Magento_Checkout/js/action/set-shipping-information': {
                'Navigate_Checkouts/js/order/set-shipping-information-mixin': true
            }
        }
    }
};