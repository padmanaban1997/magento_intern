<?php



namespace Navigate\Courses\Controller\Adminhtml\Item;


use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Filesystem;


class Save extends \Magento\Backend\App\Action
{
    /**
     * @var \Navigate\Courses\Model\GridFactory
     */
    var $gridFactory;
    protected $_mediaDirectory;
    protected $_fileUploaderFactory;
    protected $filesystem;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Navigate\Courses\Model\GridFactory $gridFactory
     */
    public function __construct(
        \Magento\Framework\Filesystem $filesystem,
        \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory,
        \Magento\Backend\App\Action\Context $context,
     
        \Magento\Framework\Filesystem\Driver\File $file,
        \Navigate\Courses\Model\GridFactory $gridFactory
    ) {
        
        $this->gridFactory = $gridFactory;
        $this->_mediaDirectory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $this->_fileUploaderFactory = $fileUploaderFactory;
        $this->filesystem = $filesystem;
        $this->_file = $file;

        parent::__construct($context);
    }

    /**
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    public function execute()
    {
      


    if ($this->getRequest()->getPostValue()) {
        try {
            $model = $this->_objectManager->create('Navigate\Courses\Model\Grid');
            $data = $this->getRequest()->getPostValue();
            if(isset($_FILES['images']['name']) && $_FILES['images']['name'] != '') {
            try{
                    //echo "hi";die;
                    $target = $this->_mediaDirectory->getAbsolutePath('navigate/courses');
            
                    $targetOne = 'navigate/courses/';
                    /** @var $uploader \Magento\MediaStorage\Model\File\Uploader */
                    $uploader = $this->_fileUploaderFactory->create(['fileId' => 'images']);
                    /** Allowed extension types */
                    $uploader->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png', 'zip', 'doc']);
                    /** rename file name if already exists */
                    $uploader->setAllowRenameFiles(true);
                    /** upload file in folder "mycustomfolder" */
                    $result = $uploader->save($target);
                    /*If file found then display message*/
                    // if ($result['file']) 
                    // {
                    //     $this->messageManager->addSuccess(__('File has been successfully uploaded')); 
                    // }
                    $imagePath = $targetOne.$result['file'];
                    $data['images'] = $imagePath;
                }
                catch (Exception $e) 
                {
                    $this->messageManager->addError($e->getMessage());
                }
            } 
                
                if(isset($data['images']['delete']) && $data['images']['delete'] == 1) {
                    $file = $data['images']['value'];
                 
                    $mediaDirectory = $this->_mediaDirectory->getAbsolutePath();
                   
                    $imgPath = $mediaDirectory.$file;
                   
                 
                    if ($this->_file->isExists($imgPath))  {
                       
                        $this->_file->deleteFile($imgPath);
                    }
                    $data['images'] = NULL;
                }
                if (isset($data['images']['value'])){
                    $data['images'] = $data['images']['value'];
                }
     
            $inputFilter = new \Zend_Filter_Input(
                [],
                [],
                $data
            );
            $data = $inputFilter->getUnescaped();
            $id = $this->getRequest()->getParam('id');
            if ($id) {
                $model->load($id);
                if ($id != $model->getEntityId()) {
                    throw new \Magento\Framework\Exception\LocalizedException(__('The wrong item is specified.'));
                }
            }
            $model->setData($data);
            $session = $this->_objectManager->get('Magento\Backend\Model\Session');
            $session->setPageData($model->getData());
            $model->save();
            $this->messageManager->addSuccess(__('You saved the item.'));
            $session->setPageData(false);
            if ($this->getRequest()->getParam('back')) {
                $this->_redirect('navigate_course/*/addrow', ['id' => $model->getId()]);
                return;
            }
            $this->_redirect('navigate_course/*/');
            return;
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addError($e->getMessage());
            $id = (int)$this->getRequest()->getParam('id');
            if (!empty($id)) {
                $this->_redirect('navigate_course/*/addrow', ['id' => $id]);
            } else {
                $this->_redirect('/*/new');
            }
            return;
        } catch (\Exception $e) {
            $this->messageManager->addError(
                __('Something went wrong while saving the item data. Please review the error log.')
            );
            $this->_objectManager->get('Psr\Log\LoggerInterface')->critical($e);
            $this->_objectManager->get('Magento\Backend\Model\Session')->setPageData($data);
            $this->_redirect('navigate_course/*/addrow', ['id' => $this->getRequest()->getParam('id')]);
            return;
        }
    }
    $this->_redirect('navigate_course/item/index');
       
    }

    /**
     * @return bool
     */ 
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Navigate_Courses::save');
    }
}