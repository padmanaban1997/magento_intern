<?php

namespace Navigate\Courses\Model;

use Navigate\Courses\Api\Data\GridInterface;

class Grid extends \Magento\Framework\Model\AbstractModel implements GridInterface
{
    /**
     * CMS page cache tag.
     */
    const CACHE_TAG = 'cc_grid_records';

    /**
     * @var string
     */
    protected $_cacheTag = 'cc_grid_records';

    /**
     * Prefix of model events names.
     *
     * @var string
     */
    protected $_eventPrefix = 'cc_grid_records';

    /**
     * Initialize resource model.
     */
    protected function _construct()
    {
        $this->_init('Navigate\Courses\Model\ResourceModel\Grid');
    }
    /**
     * Get EntityId.
     *
     * @return int
     */
    public function getEntityId()
    {
        return $this->getData(self::ENTITY_ID);
    }

    /**
     * Set EntityId.
     */
    public function setEntityId($entityId)
    {
        return $this->setData(self::ENTITY_ID, $entityId);
    }

  
    public function getImages()
    {
        return $this->getData(self::IMAGES);
    }

 
    public function setImages($images)
    {
        return $this->setData(self::IMAGES, $images);
    }


    public function getCourseTitle()
    {
        return $this->getData(self::COURSE_TITLE);
    }

 
    public function setCourseTitle($courseTitle)
    {
        return $this->setData(self::COURSE_TITLE, $courseTitle);
    }

    public function getShortDesc()
    {
        return $this->getData(self::SHORT_DESC);
    }

 
    public function setShortDesc($shortDesc)
    {
        return $this->setData(self::SHORT_DESC, $shortDesc);
    }

    public function getLongDesc()
    {
        return $this->getData(self::LONG_DESC);
    }

 
    public function setLongDesc($longDesc)
    {
        return $this->setData(self::LONG_DESC, $longDesc);
    }
    public function getDate()
    {
        return $this->getData(self::DATE);
    }

 
    public function setDate($date)
    {
        return $this->setData(self::DATE, $date);   
    }

    public function getTime()
    {
        return $this->getData(self::TIME);
    }

 
    public function setTime($time)
    {
        return $this->setData(self::TIME, $time);
    }

    public function getPerPerson()
    {
        return $this->getData(self::PER_PERSON);
    }

 
    public function setPerPerson($perPerson)
    {
        return $this->setData(self::PER_PERSON, $perPerson);
    }
    
    public function getIsActive()
    {
        return $this->getData(self::IS_ACTIVE);
    }

   
    public function setIsActive($isActive)
    {
        return $this->setData(self::IS_ACTIVE, $isActive);
    }

    public function getUpdatedAt()
    {
        return $this->getData(self::UPDATED_AT);
    }

  
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }


    public function getCreatedAt()
    {
        return $this->getData(self::CREATED_AT);
    }

  
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }
}