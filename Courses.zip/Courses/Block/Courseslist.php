<?php
namespace Navigate\Courses\Block;
use Magento\Framework\View\Element\Template;

class Courseslist extends \Magento\Framework\View\Element\Template
{
    private $_course;

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Navigate\Courses\Model\Grid $course,
        \Magento\Framework\App\ResourceConnection $resource,
        array $data = []
    ) {
        $this->_course = $course;
        $this->_resource = $resource;

        parent::__construct(
            $context,
            $data
        );
    }

    public function getCourses()   
    {
        $collection = $this->_course->getCollection();
        return $collection;
    }
}