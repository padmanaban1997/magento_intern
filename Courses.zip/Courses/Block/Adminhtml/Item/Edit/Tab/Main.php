<?php
/**
 * @category   Navigate
 * @package    Navigate_Courses
   
  
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

 
namespace Navigate\Courses\Block\Adminhtml\Item\Edit\Tab;

use Magento\Backend\Block\Widget\Form\Generic;
use Magento\Backend\Block\Widget\Tab\TabInterface;


class Main extends Generic implements TabInterface
{
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;
    protected $_wysiwygConfig;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry             $registry
     * @param \Magento\Framework\Data\FormFactory     $formFactory
     * @param array                                   $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Cms\Model\Wysiwyg\Config $wysiwygConfig,
        \Navigate\Courses\Model\Status $options,
        array $data = []
    ) 
    {
        $this->_options = $options;
        $this->_wysiwygConfig = $wysiwygConfig;
        parent::__construct($context, $registry, $formFactory, $data);
    }

      /**
     * {@inheritdoc}
     */
    public function getTabLabel()
    {
        return __(' Course Information');
    }

    /**
     * {@inheritdoc}
     */
    public function getTabTitle()
    {
        return __(' Course Information');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Prepare form.
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        
        $dateFormat = $this->_localeDate->getDateFormat(\IntlDateFormatter::SHORT);
           /** @var \Magento\Framework\Data\Form $form */
        $model = $this->_coreRegistry->registry('row_data');
        $form = $this->_formFactory->create();
      
        $form->setHtmlIdPrefix('item_');
        $fieldset = $form->addFieldset(
            'base_fieldset',
            ['legend' => __(' Course Information'), 'class' => 'fieldset-wide']
        );
    
        if ($model->getEntityId()) {
            $fieldset->addField('entity_id', 'hidden', ['name' => 'entity_id']);
        } 
           

        $fieldset->addField(
            'images',
            'image',
            array(
                'name' => 'images',
                'label' => __('Image'),
                'title' => __('Image')
            )
        
          );

        $fieldset->addField(
            'course_title',
            'text',
            [
                'name' => 'course_title',
                'label' => __('Course Title'),
                'id' => 'course_title',
                'title' => __('course_title'),
                'class' => 'required-entry',
                'required' => true,
            ]
            );
          

        $wysiwygConfig = $this->_wysiwygConfig->getConfig(['tab_id' => $this->getTabId()]);

        $fieldset->addField(
            'short_desc',
            'editor',
            [
                'name' => 'short_desc',
                'label' => __('Short Description'),
                'style' => 'height:15em;',
                'required' => true,
                'config' => $wysiwygConfig
            ]
        );
        $fieldset->addField(
            'long_desc',
            'editor',
            [
                'name' => 'long_desc',
                'label' => __('Long Description'),
                'style' => 'height:35em;',
                'required' => true,
                'config' => $wysiwygConfig
            ]
        );

        $fieldset->addField(
            'date',
            'date',
            [
                'name' => 'date',
                'label' => __('Date'),
                'id' => 'date',
                'title' => __('date'),
                'class' => 'required-entry',
                'date_format' => 'yyyy-MM-dd',
                'required' => true,
            ]
            );
            $fieldset->addField(
                'time',
                'date',
                [
                    'name' => 'time',
                    'label' => __('Time'),
                    'id' => 'time',
                    'title' => __('time'),
                    'time'=>true,
                    'date_format' => 'yyyy-MM-dd',
                    'class' => 'required-entry',
                    'time_format' => 'hh:mm:ss',
                    'required' => true,

                ]
                );
                $fieldset->addField(
                    'per_person',
                    'text',
                    [
                        'name' => 'per_person',
                        'label' => __('per person'),
                        'id' => 'per_person',
                        'title' => __('per_person'),
                        'class' => 'required-entry',
                        'required' => true,
                    ]
                    );
    

    
        $fieldset->addField(
            'is_active',
            'select',
            [
                'name' => 'is_active',
                'label' => __('Status'),
                'id' => 'is_active',
                'title' => __('Status'),
                'values' => $this->_options->getOptionArray(),
                'class' => 'status',
                'required' => true,
            ]
        );
        $form->setValues($model->getData());
      //  $form->setUseContainer(true);
        $this->setForm($form);

        return parent::_prepareForm();
    }
}