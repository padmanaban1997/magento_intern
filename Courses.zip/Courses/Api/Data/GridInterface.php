<?php

namespace Navigate\Courses\Api\Data;

interface GridInterface
{
    /**
     * Constants for keys of data array. Identical to the name of the getter in snake case.
     */
    const ENTITY_ID = 'entity_id';
    const IMAGES = 'images';
    const COURSE_TITLE = 'course_title';
    const SHORT_DESC = 'short_desc';
    const LONG_DESC = 'long_desc';
    const DATE ='date';
    const TIME ='time';
    const PER_PERSON = 'per_person';
    const IS_ACTIVE = 'is_active';
    const UPDATED_AT = 'updated_at';
    const CREATED_AT = 'created_at';
    

    /**
     * Get EntityId.
     *
     * @return int
     */
    public function getEntityId();

    /**
     * Set EntityId.
     */
    public function setEntityId($entityId);


    public function getImages();

  
    public function setImages($images);

    public function getCourseTitle();

    public function setCourseTitle($courseTitle);


    public function getShortDesc();
    public function setShortDesc($shortDesc);

    public function getLongDesc();
    public function setLongDesc($longDesc);

    public function getDate();
    public function setDate($date);

    public function getTime();
    public function setTime($time);

    public function getPerPerson();
    public function setPerPerson($perPerson);
    
    public function getIsActive();

    /**
     * Set StartingPrice.
     */
    public function setIsActive($isActive);

    public function getUpdatedAt();
    public function setUpdatedAt($updatedAt);


    public function getCreatedAt();

    /**
     * Set CreatedAt.
     */
    public function setCreatedAt($createdAt);
}