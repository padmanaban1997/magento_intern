<?php
/**
 * @category   Navigate
 * @package    Navigate_Partyorder
   
  
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace Navigate\Partyorder\Model\ResourceModel;

class Partyorder extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Define main table
     */
    protected function _construct()
    {
        $this->_init('navigate_partyorder', 'partyorder_id');   //here "navigate_partyorder" is table name and "partyorder_id" is the primary key of custom table
    }
}