<?php
/**
 * @category   Navigate
 * @package    Navigate_Partyorder
   
  
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace Navigate\Partyorder\Block;

/**
 * Partyorder content block
 */
class Partyorder extends \Magento\Framework\View\Element\Template
{
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context
    ) {
        parent::__construct($context);
    }

    public function _prepareLayout()
    {
        $this->pageConfig->getTitle()->set(__('Navigate Partyorder Module'));
        
        return parent::_prepareLayout();
    }
}
