<?php
namespace Navigate\Partyorder\Block\Menu;
class Menulist extends \Magento\Framework\View\Element\Template
{ 

    protected $_categoryFactory;
    protected $_request;  
    protected $_storeManager; 
    protected $_productCollectionFactory;
    protected $_imageHelper;
    protected $_scopeConfig;
    
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
        \Magento\Catalog\Model\CategoryFactory $categoryFactory,
        \Magento\Framework\App\Request\Http $request,
        \Magento\Catalog\Helper\Image $imageHelper,
         \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        array $data = []
    ) {
        $this->_request = $request;
        $this->_imageHelper = $imageHelper;
        $this->_categoryFactory = $categoryFactory;
        $this->_storeManager = $storeManager; 
         $this->_scopeConfig = $scopeConfig;
        $this->_productCollectionFactory = $productCollectionFactory;
        parent::__construct($context, $data);
    }
    /**
     * Get store identifier
     *
     * @return  int
     */
    public function getStoreId()
    {   
        return $this->_storeManager->getStore()->getId();
    }

    /**
     * Get store identifier
     *
     * @return  array
     */
    public function getSubcategory() {        
        $categoryTitle="Party Catering";
        $collection = $this->_categoryFactory->create()->getCollection()
              ->addAttributeToFilter('name',$categoryTitle)->setPageSize(1);

        if ($collection->getSize()) {
            $catid= $collection->getFirstItem()->getId();
        }


        $subCategory = $this->_categoryFactory->create()->load($catid);
        $subCats = $subCategory->getChildrenCategories();        
        return $subCats;
    }


    public function getPlaceholderImage(){
   return $this->getBaseUrl().'pub/media/catalog/product/placeholder/'.$this->_scopeConfig->getValue('catalog/placeholder/image_placeholder'); // Base Image

    
  /*  $this->_scopeConfig->getValue('catalog/placeholder/small_image_placeholder'); // Small Image
    $this->_scopeConfig->getValue('catalog/placeholder/swatch_image_placeholder'); // Swatch Image
    $this->_scopeConfig->getValue('catalog/placeholder/thumbnail_placeholder'); // Thumbnail Image*/
}



     /**
     * Get store identifier
     *
     * @return  int
     */
     public function getFirstItem($catid) {        
        $subCategory = $this->_categoryFactory->create()->load($catid);
        $subCats = $subCategory->getChildrenCategories();    
        foreach ($subCats as $child) { 
            return  $child->getId();       
        } 
    }

    public function getAllItem($catid)
    {

        $categoryTitle="Party Catering";
        $collection = $this->_categoryFactory->create()->getCollection()
              ->addAttributeToFilter('name',$categoryTitle)->setPageSize(1);

        if ($collection->getSize()) {
            $categoryId = $collection->getFirstItem()->getId();
        }

        $subCategory = $this->_categoryFactory->create()->load($categoryId);
        $subCats = $subCategory->getChildrenCategories();   
        $cat_ids=array();
        foreach ($subCats as $child) { 
           array_push($cat_ids,'cat_'.$child->getId()) ;       
        } 
        return $cat_ids;

    }

     /**
     * Get store identifier
     *
     * @return  string
     */  

     public function getFullActionName()
     {
        return $this->_request->getFullActionName();
     }

     public function getProductCollection($categoryId)
     {
        $category = $this->_categoryFactory->create()->load($categoryId);
        $collection = $this->_productCollectionFactory->create();
        $collection->addAttributeToSelect('*');
        $collection->addCategoryFilter($category);
        $collection->addAttributeToSort('position', 'ASC');
        $collection->addAttributeToFilter('visibility', \Magento\Catalog\Model\Product\Visibility::VISIBILITY_BOTH);
        $getProudctcollection = $collection->addAttributeToFilter('status',\Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_ENABLED);
        return $getProudctcollection;
     }

     public function getImageUrl($product)
     {
        return $this->_imageHelper->init($product, 'product_base_image')->getUrl();
     }

     public function getCategoryName($categoryId)
     {
        $category = $this->_categoryFactory->create()->load($categoryId);
        return $category->getName();
     }

      public function getMenu($categoryId)
     {
        $menu = $this->_categoryFactory->create()->load($categoryId);
        return $menu;
     }


     
    
}