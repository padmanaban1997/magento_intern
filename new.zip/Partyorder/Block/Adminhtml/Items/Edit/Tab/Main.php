<?php
/**
 * @category   Navigate
 * @package    Navigate_Partyorder
   
  
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace Navigate\Partyorder\Block\Adminhtml\Items\Edit\Tab;

use Magento\Backend\Block\Widget\Form\Generic;
use Magento\Backend\Block\Widget\Tab\TabInterface;

class Main extends Generic implements TabInterface
{
    protected $_wysiwygConfig;
 
    public function __construct(
        \Magento\Backend\Block\Template\Context $context, 
        \Magento\Framework\Registry $registry, 
        \Magento\Framework\Data\FormFactory $formFactory,  
        \Magento\Cms\Model\Wysiwyg\Config $wysiwygConfig, 
        array $data = []
    ) 
    {
        $this->_wysiwygConfig = $wysiwygConfig;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * {@inheritdoc}
     */
    public function getTabLabel()
    {
        return __('Party Order Information');
    }

    /**
     * {@inheritdoc}
     */
    public function getTabTitle()
    {
        return __('Party Order Information');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Prepare form before rendering HTML
     *
     * @return $this
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    protected function _prepareForm()
    {
        $model = $this->_coreRegistry->registry('current_navigate_partyorder_items');
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();
        $form->setHtmlIdPrefix('item_');
        $fieldset = $form->addFieldset('base_fieldset', ['legend' => __('Party Order Information')]);
        if ($model->getId()) {
            $fieldset->addField('partyorder_id', 'hidden', ['name' => 'partyorder_id']);
        }
        $fieldset->addField(
            'first_name',
            'text',
            ['name' => 'first_name', 'label' => __('First Name'), 'title' => __('First Name'), 'required' => true]
        );

         $fieldset->addField(
            'last_name',
            'text',
            ['name' => 'last_name', 'label' => __('Last Name'), 'title' => __('Last Name'), 'required' => true]
        );


        $fieldset->addField(
            'email',
            'text',
            ['name' => 'email', 'label' => __('Email'), 'title' => __('Email'), 'required' => true,'class'=>'validate-email']
        );

        $fieldset->addField(
            'phone_number',
            'text',
            ['name' => 'phone_number', 'label' => __('Phone Number'), 'title' => __('Phone Number'), 'required' => true]
        );

        $fieldset->addField(
            'number_guests',
            'text',
            ['name' => 'number_guests', 'label' => __('Number Guests'), 'title' => __('Number Guests'), 'required' => true,'class'=> 'validate-number']
        );

        $fieldset->addField(
            'date_party',
            'date',
            ['name' => 'date_party', 'date_format' => 'yyyy/MM/dd', 'label' => __('Date Of Party'), 'title' => __('Date Of Party'), 'required' => true]
        );


        $fieldset->addField(
            'time_party',
            'text',
            ['name' => 'time_party',  'label' => __('Time Of Party'), 'title' => __('Time Of Party'), 'required' => true]
        );


        $fieldset->addField(
            'location_party',
            'text',
            ['name' => 'location_party', 'label' => __('Location Of Party'), 'title' => __('Location Of Party'), 'required' => true]
        );

          $fieldset->addField(
            'menu',
            'textarea',
            ['name' => 'menu', 'label' => __('Menu'), 'title' => __('Menu'), 'required' => true]
        );

 
        
        $form->setValues($model->getData());
        $this->setForm($form);
        return parent::_prepareForm();
    }
}
