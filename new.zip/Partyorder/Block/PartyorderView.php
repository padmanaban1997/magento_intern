<?php
/**
 * @category   Navigate
 * @package    Navigate_Partyorder
   
  
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace Navigate\Partyorder\Block;

use Magento\Framework\View\Element\Template\Context;
use Navigate\Partyorder\Model\PartyorderFactory;
use Magento\Cms\Model\Template\FilterProvider;
/**
 * Partyorder View block
 */
class PartyorderView extends \Magento\Framework\View\Element\Template
{
    /**
     * @var Partyorder
     */
    protected $_partyorder;
    public function __construct(
        Context $context,
        PartyorderFactory $partyorder,
        FilterProvider $filterProvider
    ) {
        $this->_partyorder = $partyorder;
        $this->_filterProvider = $filterProvider;
        parent::__construct($context);
    }

    public function _prepareLayout()
    {
        $this->pageConfig->getTitle()->set(__('Navigate Partyorder Module View Page'));
        
        return parent::_prepareLayout();
    }

    public function getSingleData()
    {
        $id = $this->getRequest()->getParam('id');
        $partyorder = $this->_partyorder->create();
        $singleData = $partyorder->load($id);
        if($singleData->getPartyorderId() || $singleData['partyorder_id'] && $singleData->getStatus() == 1){
            return $singleData;
        }else{
            return false;
        }
    }
}