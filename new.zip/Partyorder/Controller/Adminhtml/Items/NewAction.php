<?php
/**
 * @category   Navigate
 * @package    Navigate_Partyorder
   
  
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace Navigate\Partyorder\Controller\Adminhtml\Items;

class NewAction extends \Navigate\Partyorder\Controller\Adminhtml\Items
{

    public function execute()
    {
        $this->_forward('edit');
    }
}
