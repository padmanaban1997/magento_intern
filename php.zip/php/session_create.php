<?php

   session_start();

   $_SESSION['username']="raj";

   echo "session variable is set";
   

?>