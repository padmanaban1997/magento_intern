<?php

    echo "name is :".$_POST['name']; 

    echo "<br>";


    echo "age is:".$_POST['age']; 

    


?>
