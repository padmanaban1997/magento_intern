<?php
/**
 * @category   Navigate
 * @package    Navigate_Partyorder
   
  
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace Navigate\Partyorder\Block;

use Magento\Framework\View\Element\Template\Context;
use Navigate\Partyorder\Model\PartyorderFactory;
/**
 * Partyorder List block
 */
class PartyorderListData extends \Magento\Framework\View\Element\Template
{
    /**
     * @var Partyorder
     */
    protected $_partyorder;
    public function __construct(
        Context $context,
        PartyorderFactory $partyorder
    ) {
        $this->_partyorder = $partyorder;
        parent::__construct($context);
    }

    public function _prepareLayout()
    {
        $this->pageConfig->getTitle()->set(__('Navigate Partyorder Module List Page'));
        
        if ($this->getPartyorderCollection()) {
            $pager = $this->getLayout()->createBlock(
                'Magento\Theme\Block\Html\Pager',
                'navigate.partyorder.pager'
            )->setAvailableLimit(array(5=>5,10=>10,15=>15))->setShowPerPage(true)->setCollection(
                $this->getPartyorderCollection()
            );
            $this->setChild('pager', $pager);
            $this->getPartyorderCollection()->load();
        }
        return parent::_prepareLayout();
    }

    public function getPartyorderCollection()
    {
        $page = ($this->getRequest()->getParam('p'))? $this->getRequest()->getParam('p') : 1;
        $pageSize = ($this->getRequest()->getParam('limit'))? $this->getRequest()->getParam('limit') : 5;

        $partyorder = $this->_partyorder->create();
        $collection = $partyorder->getCollection();
        $collection->addFieldToFilter('status','1');
        //$partyorder->setOrder('partyorder_id','ASC');
        $collection->setPageSize($pageSize);
        $collection->setCurPage($page);

        return $collection;
    }

    public function getPagerHtml()
    {
        return $this->getChildHtml('pager');
    }
}