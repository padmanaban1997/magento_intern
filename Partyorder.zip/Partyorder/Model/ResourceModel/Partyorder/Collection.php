<?php
/**
 * @category   Navigate
 * @package    Navigate_Partyorder
   
  
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace Navigate\Partyorder\Model\ResourceModel\Partyorder;
 
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected $_idFieldName = 'partyorder_id';
    /**
     * Define model & resource model
     */
    protected function _construct()
    {
        $this->_init(
            'Navigate\Partyorder\Model\Partyorder',
            'Navigate\Partyorder\Model\ResourceModel\Partyorder'
        );
    }
}