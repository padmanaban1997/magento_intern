<?php
/**
 * @category   Navigate
 * @package    Navigate_Partyorder
   
  
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace Navigate\Partyorder\Controller\Adminhtml\Items;

class Index extends \Navigate\Partyorder\Controller\Adminhtml\Items
{
    /**
     * Items list.
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Navigate_Partyorder::test');
        $resultPage->getConfig()->getTitle()->prepend(__('Manage Party Orders'));
        $resultPage->addBreadcrumb(__('Test'), __('Party'));
        $resultPage->addBreadcrumb(__('Items'), __('Order Items'));
        return $resultPage;
    }
}