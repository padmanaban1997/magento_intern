<?php
/**
 * @category   Navigate
 * @package    Navigate_Partyorder
   
  
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace Navigate\Partyorder\Controller\Index;

use Magento\Framework\App\Action\Context;
use Navigate\Partyorder\Model\PartyorderFactory;

class Save extends \Magento\Framework\App\Action\Action
{
	/**
     * @var Partyorder
     */
    protected $_partyorder;

    public function __construct(
		Context $context,
        PartyorderFactory $partyorder
    ) {
        $this->_partyorder = $partyorder;
        parent::__construct($context);
    }
	public function execute()
    {
        $data = $this->getRequest()->getParams();
    	$partyorder = $this->_partyorder->create();
        $partyorder->setData($data);
        if($partyorder->save()){
            $this->messageManager->addSuccessMessage(__('You saved the data.'));
        }else{
            $this->messageManager->addErrorMessage(__('Data was not saved.'));
        }
        $resultRedirect = $this->resultRedirectFactory->create();
        $resultRedirect->setPath('partyorder/index/index');
        return $resultRedirect;
    }
}
