<?php

namespace Navigate\Partyorder\Controller\Index;

use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class Catajax extends \Magento\Framework\App\Action\Action {

    /**
     * @var \Magento\Framework\App\Cache\TypeListInterface
     */
    protected $_cacheTypeList;

    /**
     * @var \Magento\Framework\App\Cache\StateInterface
     */
    protected $_cacheState;

    /**
     * @var \Magento\Framework\App\Cache\Frontend\Pool
     */
    protected $_cacheFrontendPool;

    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;
    protected $_objectManager;
    protected $_storeManager;
    protected $_filesystem;
    protected $_imageFactory;
    protected $_productCollectionFactory;
    protected $_categoryFactory;
    protected $_imageHelper;

    public function __construct(
        Context $context,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
        \Magento\Catalog\Model\CategoryFactory $categoryFactory,
        \Magento\Framework\ObjectManagerInterface $objectmanager,
        \Magento\Catalog\Helper\Image $imageHelper,
        \Magento\Framework\Image\AdapterFactory $imageFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager
    ) {
        parent::__construct($context);
        $this->_imageHelper = $imageHelper;
        $this->_objectManager = $objectmanager;
        $this->_storeManager = $storeManager;
        $this->_imageFactory = $imageFactory;
        $this->_categoryFactory = $categoryFactory;
        $this->_productCollectionFactory = $productCollectionFactory;
    }

    /**
     * Flush cache storage
     *
     */
    public function execute() {



        $categoryId = $this->getRequest()->getParam('catid');
        $category = $this->_categoryFactory->create()->load($categoryId);



             $veghtml='<div class="pop-list-inner">
                    <div class="pop-list-inner-image">
                      <img src="http://kk.navigatecommerce.com/media/catalog/category/party-page.png" width="120" height="100">
                    </div>
                    <div class="pop-list-inner-info">
                      <h4 class="pop-list-inner-title">Batata Wada -3 CHF -Min order 25</h4>
                      <p class="pop-list-inner-desc">
                        Mashed Potato balls with green herbs & dry spices coated with gram flour and deep fried . Served with dry coconut red chutney
                      </p>
                    </div>
                  </div>';



        //veg Location
        $collection = $this->_productCollectionFactory->create();
        $collection->addAttributeToSelect('*');
        $collection->addCategoryFilter($category);
        $collection->addAttributeToSort('position', 'ASC');
        $collection->addAttributeToFilter(
            array(
                array('attribute'=>'food_type','eq'=>'4')
            ));
        $getProudctcollection = $collection->addAttributeToFilter('status',\Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_ENABLED);

        $veghtml = "";

      
        $total_product=count($getProudctcollection);
         
        foreach ($getProudctcollection as $product) { 
           $image_url = $this->_imageHelper->init($product, 'product_base_image')->getUrl();
           $sku = $product->getSku();
           $veghtml.='<div class="pop-list-inner">
                    <div class="pop-list-inner-image">
                      <img src="'.$image_url.'" width="120" height="100" alt="'.$product->getName().'">
                    </div>
                    <div class="pop-list-inner-info">
                      <h4 class="pop-list-inner-title">'.$product->getName().'</h4>
                      <p class="pop-list-inner-desc">
                        '.$product->getShortDescription().'
                      </p>
                    </div>
                  </div>';
       }
      
       //End Veg collection




        //Non veg Location
        $nonvegcollection = $this->_productCollectionFactory->create();
        $nonvegcollection->addAttributeToSelect('*');
        $nonvegcollection->addCategoryFilter($category);
        $nonvegcollection->addAttributeToSort('position', 'ASC');
        $nonvegcollection->addAttributeToFilter(
            array(
                array('attribute'=>'food_type','eq'=>'5')
            ));
        $nonveggetProudctcollection = $nonvegcollection->addAttributeToFilter('status',\Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_ENABLED);

        $nonveghtml = "";

     
        $nonveg_total_product=count($nonveggetProudctcollection);
        
        foreach ($nonveggetProudctcollection as $product) { 
           $image_url = $this->_imageHelper->init($product, 'product_base_image')->getUrl();
           $sku = $product->getSku();
           $nonveghtml .= '<div class="pop-list-inner">
                    <div class="pop-list-inner-image">
                      <img src="'.$image_url.'" width="120" height="100" alt="'.$product->getName().'">
                    </div>
                    <div class="pop-list-inner-info">
                      <h4 class="pop-list-inner-title">'.$product->getName().'</h4>
                      <p class="pop-list-inner-desc">
                        '.$product->getShortDescription().'
                      </p>
                    </div>
                  </div>';
       }
  
       //End Veg collection


   
 if($total_product < 1)
 {
   $veghtml.="<span>currently not available</span>";
 }

 if($nonveg_total_product < 1)
 {
   $nonveghtml.="<span>currently not available</span>";
 }


       $result['veg_html'] = $veghtml;
       $result['nonveg_html'] = $nonveghtml;
       $result['cat_name'] =$category->getName();
       $result['cat_description'] = $category->getDescription();
       $result['veg_total_product']= $total_product;
       $result['nonveg_total_product']=$nonveg_total_product;
       $this->getResponse()->setBody(json_encode($result));
   }

}
