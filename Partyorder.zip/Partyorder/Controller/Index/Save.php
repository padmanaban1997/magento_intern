<?php
/**
 * @category   Navigate
 * @package    Navigate_Partyorder
   
  
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace Navigate\Partyorder\Controller\Index;

use Magento\Framework\App\Action\Context;
use Navigate\Partyorder\Model\PartyorderFactory;

class Save extends \Magento\Framework\App\Action\Action
{
	/**
     * @var Partyorder
     */
    protected $_partyorder;

    /**
    * @var \Magento\Framework\App\Config\ScopeConfigInterface
    */
    protected $scopeConfig;


    /**
* @var \Magento\Framework\Mail\Template\TransportBuilder
*/
protected $_transportBuilder;



    /**
    * @var \Magento\Store\Model\StoreManagerInterface
    */
    protected $storeManager;


    public function __construct(
      Context $context,
      \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
      \Magento\Store\Model\StoreManagerInterface $storeManager,
      \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
      PartyorderFactory $partyorder
  ) {
        $this->_partyorder = $partyorder;
        $this->scopeConfig = $scopeConfig;
        $this->storeManager = $storeManager;
        $this->_transportBuilder = $transportBuilder;
        parent::__construct($context);
    }
    public function execute()
    {

        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        $sendEmailTo =  $this->scopeConfig->getValue('navigate/email/party_recipient_email', $storeScope);
        $ccPartyEmailTo =  $this->scopeConfig->getValue('navigate/email/copy_to', $storeScope);
        $emailSender =  $this->scopeConfig->getValue('navigate/email/sender_email_identity', $storeScope);

        if($emailSender=='sales')
        {

            $adminSenderName= $this->scopeConfig->getValue('trans_email/ident_sales/name', $storeScope);
            $adminSenderEmail= $this->scopeConfig->getValue('trans_email/ident_sales/email', $storeScope);

        }
        elseif ($emailSender=='general') {
          $adminSenderName= $this->scopeConfig->getValue('trans_email/ident_general/name', $storeScope);
          $adminSenderEmail= $this->scopeConfig->getValue('trans_email/ident_general/email', $storeScope);
      }
      elseif ($emailSender=='support') {
          $adminSenderName= $this->scopeConfig->getValue('trans_email/ident_support/name', $storeScope);
          $adminSenderEmail= $this->scopeConfig->getValue('trans_email/ident_support/email', $storeScope);
      }
      elseif ($emailSender=='custom1') {
          $adminSenderName= $this->scopeConfig->getValue('trans_email/ident_custom1/name', $storeScope);
          $adminSenderEmail= $this->scopeConfig->getValue('trans_email/ident_custom1/email', $storeScope);
      }
      else
      {
       $adminSenderName= $this->scopeConfig->getValue('trans_email/ident_custom1/name', $storeScope);
       $adminSenderEmail= $this->scopeConfig->getValue('trans_email/ident_custom1/email', $storeScope); 
   }

    $toCc=explode(',', $ccPartyEmailTo);
    

        $data = $this->getRequest()->getParams();
        $partyorder = $this->_partyorder->create();

        if(empty($data['first_name']) || empty($data['last_name']) || empty($data['email']) || empty($data['email']) || empty($data['phone_number']) || empty($data['number_guests']) || empty($data['location_party']) || empty($data['time_party']) || empty($data['menu']))
        {
          $this->messageManager->addErrorMessage(__('Someone feild was missing '));
      }
      else
      {

        $emailTemplateVariables = array(
            'first_name' => $data['first_name'],
            'last_name' => $data['last_name'],
            'email'=>$data['email'],
            'phone_number'=>$data['phone_number'],
            'number_guests'=>$data['number_guests'],
            'location_party'=>$data['location_party'],
            'date_party'=>$data['date_party'],
            'time_party'=>$data['time_party'],
            'menu'=>$data['menu']
        );


        $to = [$sendEmailTo];
       $toBcc  = array('jaydipvaghasiya55@gmail.com','jb@gmail.com');
        $sender = array('name' => $adminSenderName,'email' => $adminSenderEmail);
        $transport = $this->_transportBuilder->setTemplateIdentifier('party_order_email_template')
        ->setTemplateOptions(
            [
                'area' => \Magento\Framework\App\Area::AREA_FRONTEND,
                'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
            ]
        )
        ->setTemplateVars($emailTemplateVariables)
        ->setFrom($sender)
        ->addTo($to)
        ->addCc($toCc)
        ->getTransport();

        $transport->sendMessage();

        $partyorder->setData($data);
        if($partyorder->save()){
            $this->messageManager->addSuccessMessage(__('Your party order data was saved.'));
        }else{
            $this->messageManager->addErrorMessage(__('Your party order Data was not saved.'));
        } 
    }

    $resultRedirect = $this->resultRedirectFactory->create();
    $resultRedirect->setPath('party-catering.html');
    return $resultRedirect;
}
}
