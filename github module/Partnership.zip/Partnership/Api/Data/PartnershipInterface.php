<?php

namespace Navigate\Partnership\Api\Data;

interface PartnershipInterface
{
    /**
     * Constants for keys of data array. Identical to the name of the getter in snake case.
     */
    const ENTITY_ID = 'entity_id';
    const FIRST_NAME = 'first_name';
    const LAST_NAME = 'last_name';
    const EMAIL = 'email';
    const TELEPHONE = 'telephone';
    const COMPANY='company';
    const WEBSITE='website'; 
    const DESCRIPTION = 'description';
    const PAYMENT_STATUS='payment_status';
    const PROGRAM_BENEFITS='program_benefits';
    const START_DATE='start_date';
    const END_DATE='end_date';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';

    /**
     * Get EntityId.
     *
     * @return int
     */
    public function getEntityId();

    /**
     * Set EntityId.
     */
    public function setEntityId($entityId);


    public function getFirstName();

    public function setFirstName($firstName);


    public function getLastName();
    public function setLastName($lastName);

    public function getEmail();

    public function setEmail($email);


    public function getTelephone();
    public function setTelephone($telephone);


    public function getCompany();
    public function setCompany($company);


    public function getWebsite();
    public function setWebsite($website);

  

    public function getDescription();
    public function setDescription($description);

    public function getPaymentStatus();
    public function setPaymentStatus($paymentStatus);
    
    public function getProgramBenefits();
    public function setProgramBenefits($programBenefits);
    
    public function getStartDate();
    
 
    public function setStartDate($startDate);
   

    public function getEndDate();
    

 
    public function setEndDate($endDate);
  
    public function getCreatedAt();

    public function setCreatedAt($createdAt);

    public function getUpdatedAt();
    public function setUpdatedAt($updatedAt);


}