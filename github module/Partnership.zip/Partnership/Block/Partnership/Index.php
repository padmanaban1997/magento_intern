<?php
namespace Navigate\Partnership\Block\Partnership;
use Magento\Framework\View\Element\Template;

class Index extends \Magento\Framework\View\Element\Template
{
    private $_partner;

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Navigate\Partnership\Model\Partnership $partner,
        \Magento\Framework\App\ResourceConnection $resource,
        array $data = []
    ) {
        $this->_partner = $partner;
        $this->_resource = $resource;

        parent::__construct(
            $context,
            $data
        );
    }

    public function getPartner()   
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $customerSession = $objectManager->create('Magento\Customer\Model\Session');

        if ($customerSession->isLoggedIn()) {
                $customerSession->getCustomerId();  // get Customer Id
                $customerSession->getCustomerGroupId();
                $customerSession->getCustomer();
                $customerSession->getCustomerData();

            //echo $customerSession->getCustomer()->getName();  // get  Full Name
            $email= $customerSession->getCustomer()->getEmail(); // get Email
            
}
        $collection = $this->_partner->getCollection();
        $customermail= $email;
        $collection->addFieldToFilter('email',$customermail);
        return $collection;

        getSelect()->__toString($collection);
    }
}