var config = {
    map: {
        '*': {

        }
    }
};