<?php

namespace Navigate\Extensionsupport\Api\Data;

interface SupportInterface
{
    /**
     * Constants for keys of data array. Identical to the name of the getter in snake case.
     */
    const ENTITY_ID = 'entity_id';
    const HELP_YOU='help_you';
    const SERVICE_PURCHASE='service_purchase';
    const EXTENSION='extension';
    const MAGENTO_EDITION='magento_edition';
    const FTP_HOST='ftp_host';
    const FTP_USER='ftp_user';
    const FTP_PASSWORD='ftp_password';
    const BACKEND_URL='backend_url';
    const BACKEND_USER='backend_user';
    const BACKEND_PASSWORD='backend_password';
    const INSTALLATION_PATH='installation_path';
    const FIRST_NAME = 'first_name';
    const LAST_NAME = 'last_name';
    const EMAIL = 'email';
    const SUBJECT='subject';
    const DESCRIPTION = 'description';
    const ATTACHMENTS='attachments';
    const STATUS = 'status';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';

    /**
     * Get EntityId.
     *
     * @return int
     */
    public function getEntityId();

    /**
     * Set EntityId.
     */
    public function setEntityId($entityId);
    
    public function setHelpYou($helpYou);


    public function getHelpYou();


    public function getServicePurchase();
    public function setServicePurchase($servicePurchase);


    public function getExtension();
    public function setExtension($extension);

    public function getMagentoEdition();
    public function setMagentoEdition($magentoEdition);

    public function getFtpHost();
    public function setFtpHost($ftpHost);

    public function getFtpUser();
    public function setFtpUser($ftpUser);

    public function getFtpPassword();
    public function setFtpPassword($ftpPassword);

    public function getBackendUrl();

    public function setBackendUrl($backendUrl);


    public function getBackendUser();
    public function setBackendUser($backendUser);

    public function getBackendPassword();
    public function setBackendPassword($backendPassword);

    public function getInstallationPath();
    public function setInstallationPath($installationPath);
    
    public function getFirstName();

    public function setFirstName($firstName);


    public function getLastName();
    public function setLastName($lastName);

    public function getEmail();

    public function setEmail($email);

    public function getSubject();
    public function setSubject($subject);


   
    public function getDescription();
    public function setDescription($description);

    public function getAttachments();
    public function setAttachments($attachments);

    public function getStatus();
    public function setStatus($status);
    



    public function getCreatedAt();

    public function setCreatedAt($createdAt);

    public function getUpdatedAt();
    public function setUpdatedAt($updatedAt);


}