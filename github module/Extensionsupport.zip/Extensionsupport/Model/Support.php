<?php

namespace Navigate\Extensionsupport\Model;

use Navigate\Extensionsupport\Api\Data\SupportInterface;

class Support extends \Magento\Framework\Model\AbstractModel implements SupportInterface
{
    /**
     * CMS page cache tag.
     */
    const CACHE_TAG = 'navigate_extensionsupport';

    /**
     * @var string
     */
    protected $_cacheTag = 'navigate_extensionsupport';

    /**
     * Prefix of model events names.
     *
     * @var string
     */
    protected $_eventPrefix = 'navigate_extensionsupport';

    /**
     * Initialize resource model.
     */
    protected function _construct()
    {
        $this->_init('Navigate\Extensionsupport\Model\ResourceModel\Support');
    }
    /**
     * Get EntityId.
     *
     * @return int
     */
    public function getEntityId()
    {
        return $this->getData(self::ENTITY_ID);
    }

    /**
     * Set EntityId.
     */
    public function setEntityId($entityId)
    {
        return $this->setData(self::ENTITY_ID, $entityId);
    }

    public function getHelpYou()
    {
        return $this->getData(self::HELP_YOU);
    }

 
    public function setHelpYou($helpYou)
    {
        return $this->setData(self::HELP_YOU, $helpYou);
    }


    public function getServicePurchase()
    {
        return $this->getData(self::SERVICE_PURCHASE);
    }

 
    public function setServicePurchase($servicePurchase)
    {
        return $this->setData(self::SERVICE_PURCHASE, $servicePurchase);
    }


    public function getExtension()
    {
        return $this->getData(self::EXTENSION);
    }

 
    public function setExtension($extension)
    {
        return $this->setData(self::EXTENSION, $extension);
    }


    public function getMagentoEdition()
    {
        return $this->getData(self::MAGENTO_EDITION);
    }

 
    public function setMagentoEdition($magentoEdition)
    {
        return $this->setData(self::MAGENTO_EDITION, $magentoEdition);
    }


    public function getFtpHost()
    {
        return $this->getData(self::FTP_HOST);
    }

 
    public function setFtpHost($ftpHost)
    {
        return $this->setData(self::FTP_HOST, $ftpHost);
    }

    public function getFtpUser()
    {
        return $this->getData(self::FTP_USER);
    }

 
    public function setFtpUser($ftpUser)
    {
        return $this->setData(self::FTP_USER, $ftpUser);
    }

    public function getFtpPassword()
    {
        return $this->getData(self::FTP_PASSWORD);
    }

 
    public function setFtpPassword($ftpPassword)
    {
        return $this->setData(self::FTP_PASSWORD, $ftpPassword);
    }

    

    public function getBackendUrl()
    {
        return $this->getData(self::BACKEND_URL);
    }

 
    public function setBackendUrl($backendUrl)
    {
        return $this->setData(self::BACKEND_URL, $backendUrl);
    }



    public function getBackendUser()
    {
        return $this->getData(self::BACKEND_USER);
    }

 
    public function setBackendUser($backendUser)
    {
        return $this->setData(self::BACKEND_USER, $backendUser);
    }

    public function getBackendPassword()
    {
        return $this->getData(self::BACKEND_PASSWORD);
    }

 
    public function setBackendPassword($backendPassword)
    {
        return $this->setData(self::BACKEND_PASSWORD, $backendPassword);
    }

    public function getInstallationPath()
    {
        return $this->getData(self::INSTALLATION_PATH);
    }

 
    public function setInstallationPath($installationPath)
    {
        return $this->setData(self::INSTALLATION_PATH, $installationPath);
    }


    public function getFirstName()
    {
        return $this->getData(self::FIRST_NAME);
    }

 
    public function setFirstName($firstName)
    {
        return $this->setData(self::FIRST_NAME, $firstName);
    }


    public function getLastName()
    {
        return $this->getData(self::LAST_NAME);
    }

 
    public function setLastName($lastName)
    {
        return $this->setData(self::LAST_NAME, $lastName);
    }


    public function getEmail()
    {
        return $this->getData(self::EMAIL);
    }

 
    public function setEmail($email)
    {
        return $this->setData(self::EMAIL, $email);
    }

    
    public function getSubject()
    {
        return $this->getData(self::SUBJECT);
    }

 
    public function setSubject($subject)
    {
        return $this->setData(self::SUBJECT, $subject);
    }


    public function getDescription()
    {
        return $this->getData(self::DESCRIPTION);
    }

 
    public function setDescription($description)
    {
        return $this->setData(self::DESCRIPTION, $description);
    }

    public function getAttachments()
    {
        return $this->getData(self::ATTACHMENTS);
    }

 
    public function setAttachments($attachments)
    {
        return $this->setData(self::ATTACHMENTS, $attachments);
    }

    public function getStatus()
    {
        return $this->getData(self::STATUS);
    }

   
    public function setStatus($status)
    {
        return $this->setData(self::STATUS, $status);
    }


    public function getCreatedAt()
    {
        return $this->getData(self::CREATED_AT);
    }


   
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    public function getUpdatedAt()
    {
        return $this->getData(self::UPDATED_AT);
    }

   
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }


}