<?php



namespace Navigate\Extensionsupport\Controller\Adminhtml\Items;


use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Filesystem;


class Save extends \Magento\Backend\App\Action
{
    /**
     * @var \Navigate\Extensionsupport\Model\SupportFactory
     */
    var $supportFactory;
    protected $_mediaDirectory;
    protected $_fileUploaderFactory;
    protected $filesystem;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Navigate\Extensionsupport\Model\SupportFactory $supportFactory
     */
    public function __construct(
        \Magento\Framework\Filesystem $filesystem,
        \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory,
        \Magento\Backend\App\Action\Context $context,
     
        \Magento\Framework\Filesystem\Driver\File $file,
        \Navigate\Extensionsupport\Model\SupportFactory $supportFactory
    ) {
        
        $this->supportFactory = $supportFactory;
        $this->_mediaDirectory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $this->_fileUploaderFactory = $fileUploaderFactory;
        $this->filesystem = $filesystem;
        $this->_file = $file;

        parent::__construct($context);
    }

    /**
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    public function execute()
    {
      


    if ($this->getRequest()->getPostValue()) {
        try {
            $model = $this->_objectManager->create('Navigate\Extensionsupport\Model\Support');
            $data = $this->getRequest()->getPostValue();
        
            // if(isset($_FILES['attachments']['name']) && $_FILES['attachments']['name'] != '') {
            // try{
            //         //echo "hi";die;
            //         $target = $this->_mediaDirectory->getAbsolutePath('navigate/extensionsupport');
            
            //         $targetOne = '';
            //         /** @var $uploader \Magento\MediaStorage\Model\File\Uploader */
            //         $uploader = $this->_fileUploaderFactory->create(['fileId' => 'attachments']);
            //         /** Allowed extension types */
            //         $uploader->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png', 'zip', 'doc']);
            //         /** rename file name if already exists */
            //         $uploader->setAllowRenameFiles(true);
            //         // $uploader->setFilesDispersion(false);
            //         // $uploader->setFilenamesCaseSensitivity(false);
                    
            //         /** upload file in folder "mycustomfolder" */
            //         $result = $uploader->save($target);
            //         /*If file found then display message*/
            //         // if ($result['file']) 
            //         // {
            //         //     $this->messageManager->addSuccess(__('File has been successfully uploaded')); 
            //         // }
            //         $imagePath = $targetOne.$result['file'];
            //         $data['attachments'] = $imagePath;
            //     }
            //     catch (Exception $e) 
            //     {
            //         $this->messageManager->addError($e->getMessage());
            //     }
            // } 
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $storeurl = $objectManager->get( 'Magento\Store\Model\StoreManagerInterface' )->getStore()->getBaseUrl();
             $result = array();
             $resultRedirect = $this->resultRedirectFactory->create ();

    if($_FILES['attachments']['name']){
        try {
            $target = $this->_mediaDirectory->getAbsolutePath('navigate/extensionsupport');
            $targetOne = '';
            $uploader = $objectManager->create('Magento\MediaStorage\Model\File\Uploader',['fileId' => 'attachments']);
            $uploader->setAllowedExtensions(['docx','pdf','jpg', 'jpeg', 'gif', 'png', 'zip']);
            $uploader->setAllowRenameFiles(true);
            //$uploader->setFilesDispersion(true);
            // get media directory
            //$mediaDirectory = $this->filesystem->getDirectoryRead(DirectoryList::MEDIA);
            // save the image to media directory
            $result = $uploader->save($target);
            //$result = $uploader->save($mediaDirectory->getAbsolutePath()."navigate/extensionsupport/");
            $imagePath = $targetOne.$result['file'];
            $data['attachments'] = $imagePath;
            
         } catch (Exception $e) {
            \Zend_Debug::dump($e->getMessage());
        }
    }

    
                
              
            $inputFilter = new \Zend_Filter_Input(
                [],
                [],
                $data
            );
            $data = $inputFilter->getUnescaped();
            $id = $this->getRequest()->getParam('id');
            if ($id) {
                $model->load($id);
                if ($id != $model->getEntityId()) {
                    throw new \Magento\Framework\Exception\LocalizedException(__('The wrong item is specified.'));
                }
            }
            $model->setData($data);
            $session = $this->_objectManager->get('Magento\Backend\Model\Session');
            $session->setPageData($model->getData());
            $model->save();
            $this->messageManager->addSuccess(__('You saved the item.'));
            $session->setPageData(false);
            if ($this->getRequest()->getParam('back')) {
                $this->_redirect('navigate_support/*/addrow', ['id' => $model->getId()]);
                return;
            }
            $this->_redirect('navigate_support/*/');
            return;
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addError($e->getMessage());
            $id = (int)$this->getRequest()->getParam('id');
            if (!empty($id)) {
                $this->_redirect('navigate_support/*/addrow', ['id' => $id]);
            } else {
                $this->_redirect('/*/new');
            }
            return;
        } catch (\Exception $e) {
            $this->messageManager->addError(
                __('Something went wrong while saving the item data. Please review the error log.')
            );
            $this->_objectManager->get('Psr\Log\LoggerInterface')->critical($e);
            $this->_objectManager->get('Magento\Backend\Model\Session')->setPageData($data);
            $this->_redirect('navigate_support/*/addrow', ['id' => $this->getRequest()->getParam('id')]);
            return;
        }
    }
    $this->_redirect('navigate_support/items/index');
       
    }

    /**
     * @return bool
     */ 
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Navigate_Extensionsupport::save');
    }
}