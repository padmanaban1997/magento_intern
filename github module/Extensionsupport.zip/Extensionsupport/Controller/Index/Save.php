<?php

namespace Navigate\Extensionsupport\Controller\Index;

use Magento\Framework\App\Action\Context;
use Navigate\Extensionsupport\Model\SupportFactory;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\UrlFactory;
use Zend_Mime;

class Save extends \Magento\Framework\App\Action\Action
{
	
    protected $_extensionsupport;
    protected $_mediaDirectory;
    /**
    * @var \Magento\Framework\App\Config\ScopeConfigInterface
    */
    protected $scopeConfig;


    /**
* @var \Magento\Framework\Mail\Template\TransportBuilder
*/
protected $_transportBuilder;


 protected $filesystem;
    /**
    * @var \Magento\Store\Model\StoreManagerInterface
    */
    protected $storeManager;


    public function __construct(
      Context $context,
      \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
      \Magento\Store\Model\StoreManagerInterface $storeManager,
      \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
      \Magento\Framework\Filesystem $filesystem,
      UrlFactory $urlFactory, 
      \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
      SupportFactory $extensionsupport
  ) {
        $this->_extensionsupport =  $extensionsupport;
        $this->scopeConfig = $scopeConfig;
        $this->inlineTranslation = $inlineTranslation;
        $this->storeManager = $storeManager;
        $this->_mediaDirectory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $this->_filesystem = $filesystem;
        $this->urlModel = $urlFactory->create ();
        $this->_transportBuilder = $transportBuilder;
        parent::__construct($context);
    }
    public function execute()
    {

        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        $sendEmailTo =  $this->scopeConfig->getValue('extensionsupport/email/extensionsupport_recipient_email', $storeScope);
        $ccEmailTo =  $this->scopeConfig->getValue('extensionsupport/email/copy_to', $storeScope);
        $emailSender =  $this->scopeConfig->getValue('extensionsupport/email/sender_email_identity', $storeScope);

        if($emailSender=='sales')
        {

            $adminSenderName= $this->scopeConfig->getValue('trans_email/ident_sales/name', $storeScope);
            $adminSenderEmail= $this->scopeConfig->getValue('trans_email/ident_sales/email', $storeScope);

        }
        elseif ($emailSender=='general') {
          $adminSenderName= $this->scopeConfig->getValue('trans_email/ident_general/name', $storeScope);
          $adminSenderEmail= $this->scopeConfig->getValue('trans_email/ident_general/email', $storeScope);
      }
      elseif ($emailSender=='support') {
          $adminSenderName= $this->scopeConfig->getValue('trans_email/ident_support/name', $storeScope);
          $adminSenderEmail= $this->scopeConfig->getValue('trans_email/ident_support/email', $storeScope);
      }
      elseif ($emailSender=='custom1') {
          $adminSenderName= $this->scopeConfig->getValue('trans_email/ident_custom1/name', $storeScope);
          $adminSenderEmail= $this->scopeConfig->getValue('trans_email/ident_custom1/email', $storeScope);
      }
      else
      {
       $adminSenderName= $this->scopeConfig->getValue('trans_email/ident_custom1/name', $storeScope);
       $adminSenderEmail= $this->scopeConfig->getValue('trans_email/ident_custom1/email', $storeScope); 
       }

    $toCc=explode(',', $ccEmailTo);

    $post = $this->getRequest()->getPostValue();

  
    if (!$post) {
        $this->_redirect('support');
        return;
    }

    $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
    $storeurl = $objectManager->get( 'Magento\Store\Model\StoreManagerInterface' )->getStore()->getBaseUrl();
    $result = array();
    $resultRedirect = $this->resultRedirectFactory->create ();
    
    if($_FILES['attachments']['name']){
        try {
            
            $uploader = $objectManager->create('Magento\MediaStorage\Model\File\Uploader',['fileId' => 'attachments']);
            $uploader->setAllowedExtensions(['docx','pdf','jpg', 'jpeg', 'gif', 'png', 'zip']);
            $uploader->setAllowRenameFiles(true);
            //$uploader->setFilesDispersion(true);
            // get media directory
            $mediaDirectory = $this->_filesystem->getDirectoryRead(DirectoryList::MEDIA);
            // save the image to media directory
            
            $result = $uploader->save($mediaDirectory->getAbsolutePath()."navigate/extensionsupport/");
            $pdfFile = $result['path'].$result['file'];

            
            $data['attachments'] = $pdfFile;

            
         } catch (Exception $e) {
            \Zend_Debug::dump($e->getMessage());
        }
    }
    $this->inlineTranslation->suspend();
     try {
        $recipientMail = $this->getRequest()->getPostValue('email');

        $postObject = new \Magento\Framework\DataObject();
        $postObject->setData($post);

        $error = false;
        $sender = array('name' => $adminSenderName,'email' => $adminSenderEmail);

          $data=$this->getRequest()->getParams(); 
           $emailTemplateVariables = array(
            'help_you' => $data['help_you'], 
            'service_purchase' => $data['service_purchase'], 
            'extension' => $data['extension'],
            'magento_edition' => $data['magento_edition'],
            'ftp_host' => $data['ftp_host'],
            'ftp_user' => $data['ftp_user'],
            'ftp_password' => $data['ftp_password'],
            'backend_url' => $data['backend_url'],
            'backend_user' => $data['backend_user'],
            'backend_password' => $data['backend_password'],
            'installation_path' => $data['installation_path'],
            'first_name' => $data['first_name'],
            'last_name' => $data['last_name'],
            'email'=>$data['email'],
            'subject'=>$data['subject'],
            'description'=>$data['description'],
           
            
        );


        $transport = $this->_transportBuilder
            ->setTemplateIdentifier('extension_support_email_frontend') // this code we have mentioned in the email_templates.xml
            ->setTemplateOptions(
                [
                    'area' => \Magento\Framework\App\Area::AREA_FRONTEND, // this is using frontend area to get the template file
                    'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
                ]
            )
            ->setTemplateVars($emailTemplateVariables)
            ->setFrom($sender)
            ->addTo($recipientMail)
            ->addAttachment(file_get_contents($pdfFile),$result['type'],$result['name'])
            ->getTransport();

        $transport->sendMessage();
        $this->inlineTranslation->resume();
      
        $this->_redirect('support');
        return;
    } 
    catch (\Exception $e) {
        $this->inlineTranslation->resume();
        $this->messageManager->addError(
            __('We can\'t process your request right now. Sorry, that\'s all we know.' . $e->getMessage())
        );
        $this->_redirect('support');
        return;
    }
    
    
    finally{
         $data = $this->getRequest()->getParams();      
         $model = $this->_extensionsupport->create();
         
         $emailTemplateVariables = array(
            'help_you' => $data['help_you'], 
            'service_purchase' => $data['service_purchase'], 
            'extension' => $data['extension'],
            'magento_edition' => $data['magento_edition'],
            'ftp_host' => $data['ftp_host'],
            'ftp_user' => $data['ftp_user'],
            'ftp_password' => $data['ftp_password'],
            'backend_url' => $data['backend_url'],
            'backend_user' => $data['backend_user'],
            'backend_password' => $data['backend_password'],
            'installation_path' => $data['installation_path'],
            'first_name' => $data['first_name'],
            'last_name' => $data['last_name'],
            'email'=>$data['email'],
            'subject'=>$data['subject'],
            'description'=>$data['description'],

         
            
        );
        
        $to = $sendEmailTo;
        $sender = array('name' => $adminSenderName,'email' => $adminSenderEmail);
        $transport = $this->_transportBuilder->setTemplateIdentifier('extension_support_email_admin')
        ->setTemplateOptions(
            [
                'area' => \Magento\Framework\App\Area::AREA_FRONTEND,
                'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
            ]
        )
        ->setTemplateVars($emailTemplateVariables)
        ->setFrom($sender)
        ->addTo($to)
        ->addCc($toCc)
        
        ->getTransport();

        $transport->sendMessage();
        


        if($_FILES['attachments']['name'])
        {
          $data['attachments']=$_FILES['attachments']['name'];
        }
 

        $model->setData($data);
        if($model->save()){
             $this->messageManager->addSuccess(
            __('Thanks for contacting us. We\'ll respond to you very soon.')
        );
        }else{
            $this->messageManager->addErrorMessage(__('We can\'t process your request right now. Sorry, that\'s all we know.'));
        } 
}

    $resultRedirect = $this->resultRedirectFactory->create();
    $resultRedirect->setPath('support');
    return $resultRedirect;
}
}
?>


