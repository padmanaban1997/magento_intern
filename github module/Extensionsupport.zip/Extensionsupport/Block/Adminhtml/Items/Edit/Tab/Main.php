<?php


namespace Navigate\Extensionsupport\Block\Adminhtml\Items\Edit\Tab;

use Magento\Backend\Block\Widget\Form\Generic;
use Magento\Backend\Block\Widget\Tab\TabInterface;


class Main extends Generic implements TabInterface
{
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;
    protected $_wysiwygConfig;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry             $registry
     * @param \Magento\Framework\Data\FormFactory     $formFactory
     * @param array                                   $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Cms\Model\Wysiwyg\Config $wysiwygConfig,
        \Navigate\Extensionsupport\Model\Status $options,
        array $data = []
    ) 
    {
        $this->_options = $options;
        $this->_wysiwygConfig = $wysiwygConfig;
        parent::__construct($context, $registry, $formFactory, $data);
    }

      /**
     * {@inheritdoc}
     */
      public function getTabLabel()
      {
        return __(' Extension Support Information');
    }

    /**
     * {@inheritdoc}
     */
    public function getTabTitle()
    {
        return __(' Extension Support Information');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Prepare form.
     *
     * @return $this
     */
    protected function _prepareForm()
    {

        $dateFormat = $this->_localeDate->getDateFormat(\IntlDateFormatter::SHORT);
        /** @var \Magento\Framework\Data\Form $form */
        $model = $this->_coreRegistry->registry('current_row_data');
        $form = $this->_formFactory->create();

        $form->setHtmlIdPrefix('item_');
        $fieldset = $form->addFieldset(
            'base_fieldset',
            ['legend' => __(' Extension Support Information'), 'class' => 'fieldset-wide']
        );

        if ($model->getEntityId()) {
            $fieldset->addField('entity_id', 'hidden', ['name' => 'entity_id']);
        } 
        $fieldset->addField(
            'help_you',
            'text',
            [
                'name' => 'help_you',
                'label' => __('Help You'),
                'id' => 'help_you',
                'title' => __('Help You'),
                'class' => 'required-entry',
                'required' => true,
            ]
        );  

        $fieldset->addField(
            'service_purchase',
            'text',
            [
                'name' => 'service_purchase',
                'label' => __('Service Purchase'),
                'id' => 'service_purchase',
                'title' => __('Service Purchase'),
                'class' => 'required-entry',
                'required' => true,
            ]
        );
        $fieldset->addField(
            'extension',
            'text',
            [
                'name' => 'extension',
                'label' => __('Extension'),
                'id' => 'extension',
                'title' => __('Extension'),
                'class' => 'required-entry',
                'required' => true,
            ]
        );  

        $fieldset->addField(
            'magento_edition',
            'text',
            [
                'name' => 'magento_edition',
                'label' => __('Magento Edition'),
                'id' => 'magento_edition',
                'title' => __('Magento Edition'),
                'class' => 'required-entry',
                'required' => true,
            ]
        ); 

        $fieldset->addField(
            'ftp_host',
            'text',
            [
                'name' => 'ftp_host',
                'label' => __(' Ftp Host'),
                'id' => 'ftp_host',
                'title' => __('Ftp Host'),
                'class' => 'required-entry',
                'required' => true,
            ]
        ); 
        $fieldset->addField(
            'ftp_user',
            'text',
            [
                'name' => 'ftp_user',
                'label' => __(' Ftp User'),
                'id' => 'ftp_user',
                'title' => __('Ftp User'),
                'class' => 'required-entry',
                'required' => true,
            ]
        );  

        $fieldset->addField(
            'ftp_password',
            'text',
            [
                'name' => 'ftp_password',
                'label' => __(' Ftp Password'),
                'id' => 'ftp_password',
                'title' => __('Ftp Password'),
                'class' => 'required-entry',
                'required' => true,
            ]
        ); 

        $fieldset->addField(
            'backend_url',
            'text',
            [
                'name' => 'backend_url',
                'label' => __('Backend Url'),
                'id' => 'backend_url',
                'title' => __('Backend Url'),
                'class' => 'required-entry',
                'required' => true,
            ]
        ); 
        $fieldset->addField(
            'backend_user',
            'text',
            [
                'name' => 'backend_user',
                'label' => __('Backend User'),
                'id' => 'backend_user',
                'title' => __('Backend User'),
                'class' => 'required-entry',
                'required' => true,
            ]
        ); 
        $fieldset->addField(
            'backend_password',
            'text',
            [
                'name' => 'backend_password',
                'label' => __('Backend Password'),
                'id' => 'backend_password',
                'title' => __('Backend Password'),
                'class' => 'required-entry',
                'required' => true,
            ]
        );  

        $fieldset->addField(
            'installation_path',
            'text',
            [
                'name' => 'installation_path',
                'label' => __('Installation Path'),
                'id' => 'installation_path',
                'title' => __('Installation Path'),
                'class' => 'required-entry',
                'required' => true,
            ]
        );  
        $fieldset->addField(
            'first_name',
            'text',
            [
                'name' => 'first_name',
                'label' => __('First Name'),
                'id' => 'first_name',
                'title' => __('First Name'),
                'class' => 'required-entry',
                'required' => true,
            ]
        );


        $fieldset->addField(
            'last_name',
            'text',
            [
                'name' => 'last_name',
                'label' => __('Last Name'),
                'id' => 'last_name',
                'title' => __('Last Name'),
                'class' => 'required-entry',
                'required' => true,
            ]
        );



        $fieldset->addField(
            'email',
            'text',
            [
                'name' => 'email',
                'label' => __('Email'),
                'id' => 'email',
                'title' => __('Email'),
                'class'=>'validate-email',
                'required' => true,
            ]
        );

        $fieldset->addField(
            'subject',
            'textarea',
            [
                'name' => 'subject',
                'label' => __('Subject'),
                'id' => 'subject',
                'title' => __('Subject'),
                'class' => 'required-entry',
                'required' => true,
            ]
        );

        



        $wysiwygConfig = $this->_wysiwygConfig->getConfig(['tab_id' => $this->getTabId()]);

        $fieldset->addField(
            'description',
            'editor',
            [
                'name' => 'description',
                'label' => __('Description'),
                'style' => 'height:8em;',
                'required' => true,
                'config' => $wysiwygConfig
            ]
        );



        $fieldset->addField(
            'attachments',
            'file',
            array(
                'name' => 'attachments',
                'label' => __('Attachments'),
                'title' => __('Attachments'),
                 'after_element_html' =>$this->getAttchement($model)
            )

        );

        $fieldset->addField(
            'status',
            'select',
            [
                'name' => 'status',
                'label' => __('Status'),
                'id' => 'status',
                'title' => __('Status'),
                'values' => $this->_options->getOptionArray(),
                'class' => 'status',
                'required' => true,
            ]
        );






        $form->setValues($model->getData());
      //  $form->setUseContainer(true);
        $this->setForm($form);

        return parent::_prepareForm();
    }

    public function getAttchement($model)
    {
        if($model->getData('attachments')){
            $url= $this->getBaseUrl().'pub/media/navigate/extensionsupport/'.$model->getData('attachments');
            return '<a href="'.$url.'" target="_blank">Click view</a>';
        }
        else
        {
            return "";
        }
        
    }
}