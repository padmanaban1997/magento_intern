<?php
namespace Navigate\Faq\Controller\Adminhtml\Faqcat;

/**
 * Class NewAction
 * @package Navigate\Faq\Controller\Adminhtml\Faqcat
 */
class NewAction extends \Navigate\Faq\Controller\Adminhtml\Faqcat
{

    /**
     *
     */
    public function execute()
    {
        $this->_forward('edit');
    }

    /**
     * @return mixed
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Navigate_Faq::faq');
    }
}
