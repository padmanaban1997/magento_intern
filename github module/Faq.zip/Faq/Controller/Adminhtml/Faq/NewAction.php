<?php
namespace Navigate\Faq\Controller\Adminhtml\Faq;

/**
 * Class NewAction
 * @package Navigate\Faq\Controller\Adminhtml\Faq
 */
class NewAction extends \Navigate\Faq\Controller\Adminhtml\Faq
{

    /**
     *
     */
    public function execute()
    {
        $this->_forward('edit');
    }

    /**
     * @return mixed
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Navigate_Faq::faq');
    }
}
