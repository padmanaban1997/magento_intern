var config = {
    map: {
        '*': {
			'highlight': 'Navigate_Faq/js/nwdthemes/jquery.highlight',
			'collapse': 'Navigate_Faq/js/nwdthemes/jquery.collapse',
			'faqpage': 'Navigate_Faq/js/nwdthemes/faqpage'
        }
    }
};