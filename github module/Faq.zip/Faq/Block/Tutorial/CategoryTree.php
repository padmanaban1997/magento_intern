<?php
namespace Navigate\Faq\Block\Tutorial;

use Magento\Framework\ObjectManagerInterface;

/**
 * Class FaqCategoryTree
 * @package Navigate\Faq\Block\Faq
 */
class CategoryTree extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Navigate\Faq\Model\FaqFactory
     */
    protected $_modelFaqFactory;



    /**
     * @var \Navigate\Faq\Helper\Data
     */
    protected $_dataHelper;
    /**
     * @var
     */
    protected $_storeManager;
    /**
     * FaqCategoryTree constructor.
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Navigate\Faq\Model\FaqcatFactory $faqCategoryFactory
     * @param \Navigate\Faq\Model\Categories $categories
     * @param \Navigate\Faq\Helper\Data $dataHelper
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Navigate\Faq\Model\FaqcatFactory $faqCategoryFactory,
        \Navigate\Faq\Model\FaqFactory $modelFaqFactory,
        \Navigate\Faq\Model\Categories $categories,
        \Navigate\Faq\Helper\Data $dataHelper
    ) {
        $this->_faqCategoryFactory = $faqCategoryFactory;
        $this->_modelFaqFactory = $modelFaqFactory;
        $this->_dataHelper = $dataHelper;
        $this->_categories = $categories;
        parent::__construct($context);
    }


      /**
     * @param $id
     * @return mixed
     */
    public function getFaqs($id)
    {
        $faqCollection = $this->_modelFaqFactory->create()->getCollection();
        if ($id) {
            $faqCollection->addFieldToFilter('faq_category', ['finset' => $id]);
        }
        $storeId = $this->_storeManager->getStore()->getStoreId();
        $faqCollection = $faqCollection->addFieldToFilter('is_active', 1);
        $faqCollection = $faqCollection->addFieldToFilter(
            'store_id',
            [
                ['finset' => $storeId],
                ['eq' => 0]
            ]
        );
        return $faqCollection;
    }





    /**
     * @return mixed
     */
    public function getFaqcategory()
    {
        $storeId =  $this->_storeManager->getStore()->getStoreId();
        $collection = $this->_faqCategoryFactory->create()
            ->getCollection()->addFieldToFilter('is_active', '1')->addFieldToFilter('type', '2')
            ->addFieldToFilter(
                'store_id',
                [['finset' => $storeId], ['eq' => 0]]
            );

        return $collection;
    }

  
   


    /**
     * @return mixed
     */
    public function getBaseUrl()
    {
        return $this->_storeManager->getStore()->getBaseUrl();
    }
    
   
}
