<?php
namespace Navigate\Faq\Block\Faq;

class FaqSearch extends \Magento\Framework\View\Element\Template
{

}
