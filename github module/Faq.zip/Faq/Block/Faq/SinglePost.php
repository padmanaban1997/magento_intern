<?php
namespace Navigate\Faq\Block\Faq;

use Magento\Framework\ObjectManagerInterface;

/**
 * Class FaqTop
 * @package Navigate\Faq\Block\Faq
 */
class SinglePost extends \Magento\Framework\View\Element\Template
{

    /**
     * @var \Navigate\Faq\Model\FaqFactory
     */
    protected $_modelFaqFactory;
    /**
     * @var null
     */
    protected $_faqCollection = null;
    /**
     * @var \Navigate\Faq\Helper\Data
     */
    protected $_dataHelper;

    /**
     * @var \Magento\Cms\Model\Template\FilterProvider
     */
    protected $_filterProvider;


    /**
     * FaqTop constructor.
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Navigate\Faq\Model\FaqFactory $modelFaqFactory
     * @param \Navigate\Faq\Model\FaqcatFactory $faqCategoryFactory
     * @param \Navigate\Faq\Helper\Data $dataHelper
     * @param \Navigate\Faq\Model\Categories $categories
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Navigate\Faq\Model\FaqFactory $modelFaqFactory,
        \Navigate\Faq\Model\FaqcatFactory $faqCategoryFactory,
        \Navigate\Faq\Helper\Data $dataHelper,
        \Magento\Cms\Model\Template\FilterProvider $filterProvider,
        \Navigate\Faq\Model\Categories $categories
    ) {
        parent::__construct($context);
        $this->_modelFaqFactory = $modelFaqFactory;
        $this->_faqCategoryFactory = $faqCategoryFactory;
        $this->_dataHelper = $dataHelper;
        $this->_categories = $categories;
        $this->_filterProvider = $filterProvider;
    }


    
    protected function _prepareLayout()
    {

        $metaTitle = $this->_dataHelper->getMetaTitle();
        $metaKeywords = $this->_dataHelper->getMetaKeyword();
        $metaDescription = $this->_dataHelper->getMetaDescription();
        $pageTitle = $this->_dataHelper->getPageTitle();

        $data=$this->getFaqTops();
        
        if(count($data)==0)
        {

           $urlkey=trim($this->getRequest()->getParam("url"));
           $NewurlKey='Location:'.$this->getBaseUrl().$urlkey.'.html';

           header($NewurlKey);   
       }



       $_post=array();
       foreach ($data as $_post) {

       }


       if (!empty($_post->getTitle())) {
        $this->pageConfig->getTitle()->set($_post->getTitle());
    } else {
        $this->pageConfig->getTitle()->set(__('FAQs'));
    }

    if (!empty($_post->getMetaKeywords())) {
        $this->pageConfig->setKeywords($_post->getMetaKeywords());
    } else {
        $this->pageConfig->setKeywords(__('FAQs'));
    }

    if (!empty($_post->getMetaDescription())) {
        $this->pageConfig->setDescription($_post->getMetaDescription());
    } else {
        $this->pageConfig->setDescription(__('FAQs'));
    }

    return parent::_prepareLayout();
}

    /**
     * @param $id
     * @return mixed
     */
    public function getFaqTops()
    {
        $urlkey=trim($this->getRequest()->getParam("url"));
        $storeId = $this->_storeManager->getStore()->getStoreId();
        $faqCollection = $this->_modelFaqFactory->create()->getCollection();
        $faqCollection = $faqCollection->addFieldToFilter('is_active', 1);
        $faqCollection = $faqCollection->addFieldToFilter('url_key', $urlkey);
        $faqCollection = $faqCollection->addFieldToFilter(
            'store_id',
            [
                ['finset' => $storeId],
                ['eq' => 0]
            ]
        );


        if(count($faqCollection)==0)
        {

          $NewurlKey='Location:'.$this->getBaseUrl().$urlkey.'.html';
         header($NewurlKey);   
       }


      return $faqCollection;
  }

     /**
     * Prepare HTML content
     *
     * @return string
     */
     public function getCmsFilterContent($value='')
     {
        $html = $this->_filterProvider->getPageFilter()->filter($value);
        return $html;
    }
    
}
