<?php
namespace Navigate\Faq\Model;

use Magento\Framework\Model\AbstractModel;

/**
 * Class Faq
 * @package Navigate\Faq\Model
 */
class Faq extends AbstractModel
{

    /**
     *
     */
    protected function _construct()
    {
        $this->_init('Navigate\Faq\Model\ResourceModel\Faq');
    }
}
