<?php
namespace Navigate\Faq\Model;

use Magento\Framework\Model\AbstractModel;

/**
 * Class Faqcat
 * @package Navigate\Faq\Model
 */
class Faqcat extends AbstractModel
{

    /**
     *
     */
    protected function _construct()
    {
        $this->_init('Navigate\Faq\Model\ResourceModel\Faqcat');
    }

    /**
     * @param $urlKey
     * @return mixed
     */
    public function checkUrlKey($urlKey)
    {
        return $this->_getResource()->checkUrlKey($urlKey);
    }
}
