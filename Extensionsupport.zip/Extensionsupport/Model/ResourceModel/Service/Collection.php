<?php


namespace Navigate\Extensionsupport\Model\ResourceModel\Service;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'entity_id';
    /**
     * Define resource model.
     */
    protected function _construct()
    {
        $this->_init('Navigate\Extensionsupport\Model\Service', 'Navigate\Extensionsupport\Model\ResourceModel\Service');
    }
}