<?php

namespace Navigate\Extensionsupport\Api\Data;

interface ServiceInterface
{
    /**
     * Constants for keys of data array. Identical to the name of the getter in snake case.
     */
    const ENTITY_ID = 'entity_id';
    const FIRST_NAME = 'first_name';
    const LAST_NAME = 'last_name';
    const EMAIL = 'email';
    const COMPANY='company';
    const TELEPHONE = 'telephone';
    const WEBSITE='website'; 
    const PURCHASED_EXTENSION='purchased_extension';
    const MAGENTO_PRODUCT='magento_product';
    const DESCRIPTION = 'description';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';

    /**
     * Get EntityId.
     *
     * @return int
     */
    public function getEntityId();

    /**
     * Set EntityId.
     */
    public function setEntityId($entityId);


    public function getFirstName();

    public function setFirstName($firstName);


    public function getLastName();
    public function setLastName($lastName);

    public function getEmail();

    public function setEmail($email);

    public function getCompany();
    public function setCompany($company);

    public function getTelephone();
    public function setTelephone($telephone);


    public function getWebsite();
    public function setWebsite($website);

    public function getPurchasedExtension();
    public function setPurchasedExtension($purchasedExtension);

    public function getMagentoProduct();
    public function setMagentoProduct($magentoProduct);

    public function getDescription();
    public function setDescription($description);

    public function getCreatedAt();

    public function setCreatedAt($createdAt);

    public function getUpdatedAt();
    public function setUpdatedAt($updatedAt);


}